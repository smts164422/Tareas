package com.example.miagenda_ws.clases;

public class Configuraciones {
    public String urlWebServices;

    public Configuraciones() {
        this.urlWebServices = "https://emmanuelwebserviceapp.000webhostapp.com/ws_app/webservices02.php";
    }
}
