package com.example.miagenda_ws.clases;

public class Configuraciones {
    public String urlWebServices;

    public Configuraciones() {
        this.urlWebServices = "https://192.168.1.4/ws_app/webservices02.php";
    }
}
